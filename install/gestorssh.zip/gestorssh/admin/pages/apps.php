
<center>




<br></br>

<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
	<link rel="stylesheet" href="./css/reset.min.css">
    <link rel="stylesheet" href="./css/default.css">
    <link rel="stylesheet" href="./css/style.css">
    <title> Painel SSH SMS</title>
	
	
 <div class="container">

      

        <main class="main">
            <div class="credit">
                Super Net 4G SMS</a>
            </div>
        </main>
		
		
		<?php
  $pagina = "texto.txt";
  if(isset($_POST)){
    if(@$_POST["conteudo"]){
      $fopen = fopen($pagina,"w+");
      fwrite($fopen,$_POST["conteudo"]);
      fclose($fopen);
    }
  }
?>
<h1>PAINEL: <?= $pagina; ?></h1>

 <a href="texto.txt?=1871" target="_blank"><img src="104647.png" width="50px; height: 50px;"> </a> 


<form method="post">
  <textarea name="conteudo" style="width: 994px; height: 117px;" >  <?= file_get_contents($pagina); ?></textarea><br></br>
  <input type="submit" value="SALVAR O CODIGO" style="width: 294px; height: 50px;"/>
</form>
	
		

        <footer class="footer">
            <address>
                Criação e Desenvolvimento: <a href="https://supernet4g.netlify.app">SUPER NET INTERMET ILIMITADA</a> &copy; 2023 </a>
            </address>
        </footer>
    </div>
</body>
</html>

 